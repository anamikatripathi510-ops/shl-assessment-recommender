# SHL AI Intern Assignment

An AI-powered chatbot that recommends SHL assessments based on hiring needs, using Google Gemini for multi-turn conversation.

## Run & Operate

- **Start server:** `cd artifacts/fastapi-server && uvicorn app:app --host 0.0.0.0 --port 8000 --reload`
- **Workflow:** "FastAPI Server" (auto-managed by Replit)
- **Re-scrape catalog:** `cd artifacts/fastapi-server && python scrape_catalog.py`
- **Required secret:** `GEMINI_API_KEY` — Google Gemini API key

## Stack

- Python 3.11, FastAPI, Uvicorn
- Google Gemini (`google-genai`) — `gemini-2.5-flash` model
- Pydantic v2 for request/response validation
- BeautifulSoup4 + lxml for catalog scraping

## Where things live

```
artifacts/fastapi-server/
├── app.py            — FastAPI app: /health and /chat endpoints
├── models.py         — Pydantic models (ChatRequest, ChatResponse, Recommendation)
├── prompts.py        — SYSTEM_PROMPT with SHL catalog injected at runtime
├── recommender.py    — Gemini API client, multi-turn chat logic
├── catalog.json      — 20-entry SHL assessment catalog (name, url, test_type, description)
├── scrape_catalog.py — Utility to refresh catalog.json from SHL website
└── requirements.txt
```

## Architecture decisions

- **catalog.json loaded at startup** and injected into the Gemini system prompt — no DB needed.
- **Stateless endpoint:** the client sends the full `messages[]` history each request; server is sessionless.
- **JSON response mode** enforced via `response_mime_type="application/json"` so the model always returns parseable output.
- **google-genai** (not deprecated `google-generativeai`) used for the Gemini SDK.
- SHL catalog pages are JS-rendered; catalog.json is hand-curated from authoritative SHL product data; `scrape_catalog.py` supplements with live scraping when possible.

## Product

- `GET /health` → `{"status":"ok"}`
- `POST /chat` accepts `{"messages":[{"role":"user","content":"..."}]}` and returns `{"reply":"...","recommendations":[...],"end_of_conversation":false}`
- Supports: clarification, recommendation (1–10 results), refinement, and comparison
- Stays strictly scoped to SHL assessments only

## Deployment on Replit

1. Ensure `GEMINI_API_KEY` is set in Replit Secrets.
2. The "FastAPI Server" workflow runs `uvicorn app:app --host 0.0.0.0 --port 8000`.
3. For deployment, the `Procfile` uses `${PORT:-8000}` to respect Replit's assigned port.
4. No database required.

## Gotchas

- The model singleton is initialised lazily on first request — first call may be ~1s slower.
- If the Gemini API key is missing, `/chat` returns HTTP 500 with a clear error message.
- `scrape_catalog.py` only scrapes pages that render server-side; the Verify cognitive test sub-pages are JS-rendered and therefore hand-curated in catalog.json.
